// localStorage-backed profile storage. No backend, no auth — this is the
// entire "family account" concept for v1. Two keys:
//   iky-profiles        -> Profile[]
//   iky-active-profile   -> string (profile id)
//
// Deliberately plain (no context/provider) so it's usable from both client
// components and simple event handlers without extra wiring. If Learn Mode
// grows enough state to justify a provider, wrap these later — don't build
// that ahead of need.

import { type Profile } from "@/types/profile";

const PROFILES_KEY = "iky-profiles";
const ACTIVE_PROFILE_KEY = "iky-active-profile";

function isBrowser() {
  return typeof window !== "undefined";
}

export function getProfiles(): Profile[] {
  if (!isBrowser()) return [];
  try {
    const raw = window.localStorage.getItem(PROFILES_KEY);
    return raw ? (JSON.parse(raw) as Profile[]) : [];
  } catch {
    return [];
  }
}

export function saveProfile(profile: Profile): void {
  if (!isBrowser()) return;
  const profiles = getProfiles();
  profiles.push(profile);
  window.localStorage.setItem(PROFILES_KEY, JSON.stringify(profiles));
  // First profile created becomes active by default.
  if (!getActiveProfileId()) {
    setActiveProfileId(profile.id);
  }
}

export function deleteProfile(profileId: string): void {
  if (!isBrowser()) return;
  const remaining = getProfiles().filter((p) => p.id !== profileId);
  window.localStorage.setItem(PROFILES_KEY, JSON.stringify(remaining));
  if (getActiveProfileId() === profileId) {
    window.localStorage.removeItem(ACTIVE_PROFILE_KEY);
    if (remaining[0]) setActiveProfileId(remaining[0].id);
  }
}

export function getActiveProfileId(): string | null {
  if (!isBrowser()) return null;
  return window.localStorage.getItem(ACTIVE_PROFILE_KEY);
}

export function setActiveProfileId(profileId: string): void {
  if (!isBrowser()) return;
  window.localStorage.setItem(ACTIVE_PROFILE_KEY, profileId);
}

export function getActiveProfile(): Profile | null {
  const id = getActiveProfileId();
  if (!id) return null;
  return getProfiles().find((p) => p.id === id) ?? null;
}